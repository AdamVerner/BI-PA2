//
// Created by home-6 on 12.05.20.
//

#pragma once

#include <vector>
#include <cstdint>

typedef std::vector<std::vector<uint8_t>> imgData_t;
typedef std::vector<uint8_t> imgDataRow_t;
