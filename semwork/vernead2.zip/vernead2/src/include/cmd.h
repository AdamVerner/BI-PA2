//
// Created by vernead2 on 30.04.20.
//

#pragma once

int main(int argc, char *argv[]);
void help();